All documentation is made available at https://infiniteajaxscroll.com/docs.
